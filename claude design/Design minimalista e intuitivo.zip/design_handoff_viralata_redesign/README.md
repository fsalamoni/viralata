# Handoff: Redesign completo do Viralata

## Overview
Redesign integral do app de adoção de pets Viralata: unifica a identidade visual (hoje aplicada só em Home/Feed) em todas as ~14 telas, e adiciona duas funcionalidades novas — módulo **Organizações** (gestão de ONGs com planilha em massa de animais, doações, prestação de contas e equipe com permissões) e **filtro de localização/raio** no Feed.

## About the Design Files
Os arquivos deste pacote são **referências de design em HTML/React-like (Design Component)** — protótipos navegáveis que mostram visual e comportamento pretendidos, **não código de produção para copiar diretamente**. A tarefa é **recriar este design no ambiente já existente do repositório** (`fsalamoni/viralata`: React + Vite + Tailwind + shadcn/ui + Firebase/Firestore), reaproveitando os componentes de `src/components/ui/*`, os hooks e o padrão de módulos em `src/modules/*`. Não introduza uma stack nova.

## Fidelity
**Alta fidelidade (hifi)**: cores exatas, tipografia, espaçamento e interações estão definidas abaixo e no arquivo `Viralata.dc.html`. Recrie pixel a pixel usando os componentes existentes do projeto (Tailwind classes / shadcn) em vez de inline styles — o protótipo usa inline styles apenas porque é a ferramenta de prototipagem, isso **não deve** ir para o código de produção.

## Design Tokens

**Cores** (definidas em HSL, uso consistente em todo o app):
- Fundo base: `hsl(38 45% 97%)` (creme) — telas internas usam `hsl(34 40% 94%)` como variação em heros/onboarding
- Texto principal: `hsl(20 25% 13%)`
- Texto secundário: `hsl(20 12% 40%)` / `hsl(20 12% 45%)`
- Primária (laranja terracota): gradiente `hsl(17 72% 45%) → hsl(40 88% 54%)` — usado em CTAs, ícone do app, destaques
- Acento verde-oliva (tags de temperamento, "Comunidade"): `hsl(86 30% 32%)` / texto `hsl(86 34% 24%)`
- Dourado (badges de prioridade, avisos): `hsl(40 88% 54%)`
- Erro/denúncia: `hsl(9 62% 46%)`
- Sucesso/financeiro positivo: `hsl(150 38% 36%)`
- Superfícies (cards): `hsl(30 45% 99%)` com borda `1px solid white` e `box-shadow: 0 18-30px 40-70px -28/-32px hsl(20 40% 20% / 0.35-0.45)`
- Cores de avatar/gradiente por item (rotacionadas por índice `hue`):
  1. `linear-gradient(135deg,#E8875F,#C1502E)`
  2. `linear-gradient(135deg,#C9A876,#8B6F47)`
  3. `linear-gradient(135deg,#E3B94A,#C1502E)`
  4. `linear-gradient(135deg,#9CAA6B,#5F6B3E)`
  5. `linear-gradient(135deg,#D98E52,#8B5E34)`

**Tipografia**:
- Display/headings: `Sora`, pesos 600–800, `letter-spacing: -0.02em a -0.03em`
- Corpo/UI: `Manrope`, pesos 400–800
- Ícones: Material Symbols Outlined (via Google Fonts) — considerar trocar por `lucide-react` (já usado no projeto, conforme shadcn) mantendo os mesmos glifos semânticos (pets, favorite, location_on, chat_bubble, corporate_fare, table_chart, account_balance, admin_panel_settings, etc.)

**Espaçamento/raio**:
- Cards: `border-radius: 18–28px`
- Pills/botões: `border-radius: 999px` (full)
- Inputs: `border-radius: 12–16px`, borda `2px solid hsl(30 20% 89%)`, foco não foi estilizado no protótipo — adicionar `focus-visible:ring` do padrão shadcn
- Sombras: sempre difusas e escuras-quentes (`hsl(20 40% 20% / 0.35-0.45)`), nunca cinza puro — é o que dá o tom "orgânico"

**Layout responsivo**: breakpoint mobile em `vw < 860`. Desktop usa header fixo com nav pill central; mobile usa header compacto + bottom tab bar fixa (padding-bottom no `<main>` para não sobrepor conteúdo).

## Files
- `Viralata.dc.html` — protótipo completo navegável (abrir em qualquer navegador). Contém TODAS as telas abaixo em uma única SPA client-side com estado em memória (sem persistência real).

---

## Screens / Views

### 1. Home (pública, `/`)
**Propósito**: landing page para visitantes não autenticados.
**Layout**: hero em grid 2 colunas (desktop) / 1 coluna centralizada (mobile) com blob orgânico à direita (border-radius assimétrico simulando forma orgânica, `44% 56% 58% 42% / 46% 42% 58% 54%`), badges flutuantes de prova social ("+500 adoções", "100% sem custo"). Seções seguintes: estatísticas de impacto (4 números em grid), "Como funciona" (3 passos numerados), histórias de adoção (3 cards com citação), grid de funcionalidades (4 cards), CTA final em card escuro (`linear-gradient(150deg, hsl(14 55% 30%), hsl(20 30% 16%))`), footer.
**Dados**: `impactStats`, `howItWorks`, `stories` (depoimentos), `features` — todos mockados, substituir por dados reais/CMS.
**CTAs**: "Ver Pets para Adoção" → Feed (ou Login se deslogado); "Cadastrar meu Pet" / "Criar minha conta grátis" → Login.

### 2. Login (`/login`)
**Layout**: split screen — coluna esquerda (desktop apenas) com copy institucional em fundo escuro + depoimento; coluna direita com card de login centralizado, único CTA "Continuar com Google" (ícone Google oficial em SVG inline).
**Comportamento**: login mockado só seta `isAuthenticated=true` e navega para Onboarding. Produção: integrar Firebase Auth (Google provider), redirecionar para onboarding **apenas se o perfil de adotante ainda não foi preenchido**.

### 3. Onboarding — questionário (`/onboarding`)
**Layout**: card único centralizado, progress dots (ícone de pata preenchendo conforme avança), 7 passos:
1. Tipo de moradia (radio com ícone) — `housing_type`
2. Rotina de passeios (radio) — `daily_walks`
3. Composição familiar (checkboxes: crianças + idade, idosos) — `has_children`, `children_ages`, `has_elderly`
4. Outros animais (multi-select ou "não tenho") — `other_pets[]`
5. Orçamento (radio) — `budget_level`
6. Cidade/Estado (2 inputs texto) — `city`, `state`
7. Consentimento LGPD (checkbox obrigatório) — `lgpd_consent`
**Validação**: botão "Continuar" desabilitado até resposta válida no passo atual (radio: campo preenchido; local: cidade ≥2 chars e estado = 2 chars; consentimento: true). Botão "Voltar" oculto no passo 1.
**Ao concluir**: grava perfil de adotante do usuário, navega para Feed.

### 4. Feed (`/feed`) — tela mais complexa
**Header de filtros**: chips de espécie (Todos/Cães/Gatos/Coelhos), chips de porte (6 opções), **novo**: input de cidade + chips de raio (5/10/25/50/100 km) com texto de resumo ("Pets até 25 km de Belo Horizonte").
**Seção "Descobrir" (swipe)**: stack de até 3 cards sobrepostos (o de cima é arrastável via pointer events — `translateX` + rotação proporcional ao arrasto; acima de 90px decide like/pass); overlays "CURTIR"/"AGORA NÃO" com opacidade proporcional ao arrasto; botões redondos ✕ / ♥ abaixo como alternativa ao swipe; ícone "i" no canto abre o detalhe.
**Seção grid**: todos os pets filtrados, cards com foto, nome, 2 tags de temperamento, badge de prioridade (dourado, `⚡ PRIORIDADE`), tempo de espera colorido (vermelho se >150 dias) e cidade.
**Estado**: `filterSpecies`, `filterSize`, `feedCity`, `feedRadius`, `cardState` (por pet: exit-like/exit-pass/gone), `interestedIds`.
**Produção**: raio de distância precisa de geocoding real (Firestore + geohash ou API de distância) — no protótipo é só um filtro visual de cidade por texto.

### 5. Detalhe do Pet (`/pets/:id`)
**Layout**: 2 colunas (desktop) — foto grande à esquerda (com overlay "Adotado com amor" se status=adopted); direita: título, raça, badges (espécie/porte/idade/sexo/castrado/vacinado/vermifugado), tags de temperamento, tempo de espera + localização, bloco "Sobre o pet" (história), blocos condicionais de observações de saúde (fundo dourado) e requisitos de adoção (fundo verde-oliva), card do responsável com botão "Conversar" → Chat, botões "Compartilhar" e "Tenho Interesse em Adotar" (desabilitado após clicar ou se já adotado).

### 6. Cadastrar/Editar Pet (`/pets/novo`, `/pets/:id/editar`)
**Layout**: wizard de 4 passos com barra de progresso segmentada: Fotos (grid de até 6, botão adicionar) → Sobre (título, nome, espécie/porte/idade/sexo em chips, raça, cidade/estado) → Saúde (vacinação em chips, 7 checkboxes de atributos, 2 textareas) → Revisão (resumo com todos os badges + textos, botão final "Cadastrar Pet"/"Salvar alterações").
**Validação por passo**: Fotos exige ≥1 foto; Sobre exige título+espécie+porte+idade+sexo+cidade+estado; Saúde exige vacinação selecionada.

### 7. Meus Pets (`/meus-pets`)
**Layout**: lista de cards horizontais (foto, nome, status colorido, contagem de interessados, botões editar/excluir). Botão "Novo" no header leva ao wizard de cadastro.

### 8. Perfil (`/perfil`)
**Layout**: card de cabeçalho (avatar, nome, email, estrelas de avaliação, badge "Guardiã Nível X", "Membro desde"); card "Dados pessoais" (nome, telefone, cidade/UF, gênero em chips, switch "exibir telefone publicamente"); card "Perfil de adotante" (mesmos campos do onboarding, editáveis); card "Privacidade e dados" (baixar dados / excluir conta com modal de confirmação, texto explicando anonimização em vez de exclusão física — requisito de LGPD).
**Nota de unificação**: esta era a tela mais fora do padrão visual no código atual (Tailwind genérico) — no redesign segue os mesmos cards/sombras/cores de todo o app.

### 9. Organizações — Hub (`/organizacoes`) — **NOVO**
**Propósito**: ponto de entrada do módulo de gestão de ONGs, entre Feed e Comunidade na navegação.
**Layout**: seção "Minhas organizações" (cards das ONGs onde o usuário tem papel de owner/admin, com badge do papel, clique abre o Painel de Administração); seção "Descobrir outras organizações" (as demais ONGs da plataforma, clique abre o perfil público — reaproveita a tela de Comunidade/Detalhe da Organização).
**Regra de acesso**: só aparece em "Minhas organizações" se o usuário tiver um registro de papel para aquela ONG (ver Modelo de Dados abaixo). Tentar abrir administração sem permissão deve ser bloqueado (o protótipo mostra um toast de erro).

### 10. Organizações — Painel de Administração (`/organizacoes/:id/admin`) — **NOVO**
**Acesso**: visível e navegável apenas para o criador (owner) da ONG e usuários com papel de admin atribuído por ele. Tabs renderizadas condicionalmente por permissão do usuário logado (ver seção Permissões).
**Header**: banner com gradiente da ONG, avatar com iniciais, nome + selo de verificação, localização.
**Tabs** (cada uma some se o usuário não tiver a permissão correspondente):

  **10.1 Visão Geral** (sem permissão específica — todo membro do time vê): 3 KPIs (animais cadastrados, seguidores, ano de fundação) + descrição da ONG.

  **10.2 Animais** (permissão `animals`) — **planilha de gestão em massa**:
  - Tabela editável inline: colunas Foto (botão redondo que troca a cor/imagem do animal — no protótipo cicla um gradiente, em produção abre um upload), Nome (input texto), Espécie (select), Porte (select), Raça (input texto), Cidade (input texto), Status (select: Disponível/Em processo/Adotado), e um botão de excluir linha.
  - Botões no topo: **"Baixar planilha modelo"** (gera um `.xlsx` com todas as colunas necessárias e validações de dropdown por coluna — usar biblioteca tipo `SheetJS/xlsx` no front ou gerar server-side), **"Importar planilha"** (abre modal de upload), **"Nova linha"** (adiciona animal em branco à tabela), **"Salvar alterações"** (persiste a tabela toda).
  - **Modal de importação**: aceita `.xlsx`, `.csv`, `.json` (aceitar outros formatos estruturados/não estruturados foi pedido — para não-estruturado, considere um parser assistido por LLM que mapeia colunas livres para o schema, com preview antes de confirmar). Após "processar" o arquivo, mostra 3 contadores (novos / já cadastrados / com erro) e:
    - Lista de **duplicados** (linha + identificador do animal) com botões por item **"Manter atual"** / **"Substituir"** — a escolha é por item, não global.
    - Lista de **erros** com número da linha, campo e mensagem exata (ex: valor de porte inválido, campo obrigatório vazio).
    - Botão "Confirmar importação" só executa o que foi decidido: insere novos, atualiza os marcados como "Substituir", ignora os "Manter atual" e os com erro.
  - **Regra de deduplicação**: identificador do animal (ex: um `petId`/código gerado ou microchip, defina o campo-chave no modelo real) é comparado com os já cadastrados da ONG antes de decidir novo vs. duplicado.

  **10.3 Mural da ONG** (permissão `feed`): feed de posts específico da ONG, mesmo componente visual do feed geral de Comunidade (post = autor, papel, tempo, texto, curtir, comentar), porém escopado só a posts desta organização.

  **10.4 Chamados de Doação** (permissão `donations`): lista de campanhas ativas (título, barra de progresso arrecadado/meta, prazo) + botão "Novo chamado de doação". Campanha 100% atingida deve poder ser marcada como concluída (mostrar prazo "Concluída").

  **10.5 Prestação de Contas** (permissão `finance`): filtro por período (Mensal/Semestral/Anual) — 3 cards de totais (Receitas em verde, Despesas em vermelho, Saldo colorido conforme sinal) + duas listas com barras de proporção (Receitas por categoria, Despesas por categoria). Valores em BRL formatados (`toLocaleString('pt-BR')`).

  **10.6 Equipe** (permissão `team`): formulário de convite por email (cria pendência de convite — no protótipo é só um toast); lista de membros com avatar, nome, email, badge do papel (Proprietário/Administrador) e **5 toggles de permissão granular por membro** (Gerenciar animais, Prestação de contas, Chamados de doação, Publicar no mural, Gerenciar equipe) — o owner não pode ter permissões desmarcadas/removidas.

### 11. Comunidade — Diretório (`/comunidade`) — mantém como está
Lista/busca de todas as ONGs e lojas parceiras da plataforma (independente de o usuário administrar ou não) — é o diretório público, diferente do hub de Organizações que é a área de **gestão**. Card com iniciais, selo verificado, descrição truncada, contagem de membros/pets.

### 12. Comunidade — Detalhe da Organização (`/comunidade/:id`) — mantém como está
Perfil público de uma ONG/loja: banner, botão Participar/Participando, 3 métricas, tabs Mural / Eventos / Sobre. Eventos têm RSVP ("Confirmar presença" ↔ "Presença confirmada ✓").

### 13. Chat (`/chat`)
**Layout desktop**: split view lista+thread lado a lado. **Mobile**: navegação em pilha (lista → thread, botão voltar volta pra lista sem sair da tela de Chat).
**Dados**: conversas mockadas por pet/contexto e um grupo. Mensagens com bolha diferenciada (própria = gradiente laranja à direita; do outro = cinza à esquerda).

### 14. Denúncia de Maus-Tratos (`/denuncia`)
**Formulário**: descrição (textarea), endereço + botão "GPS" (captura coordenadas), upload de até 5 fotos.
**Após envio**: gera protocolo (`VL-XXXXXX`) e mostra um **documento formatado para impressão/PDF** (cabeçalho com marca, data, protocolo, dados do denunciante, descrição) + botão "Baixar PDF para Autoridades" (produção: gerar PDF real, ex. `pdf-lib`/server-side) + "Voltar ao início".

### 15. Painel Admin da plataforma (`/admin`)
**Dashboard**: 5 KPIs (pets ativos/total, usuários, denúncias pendentes, organizações, adoções no mês) + grid de 5 seções (Gerenciar Pets, Organizações, Denúncias, Usuários, Métricas). Só "Gerenciar Pets" tem uma segunda tela implementada no protótipo (tabela simples de todos os pets da plataforma); as demais mostram um toast "em breve" — precisam de telas reais em produção.

---

## Interactions & Behavior (globais)
- **Navegação**: SPA com histórico próprio em memória (`history` stack) — em produção usar React Router com rotas reais (ver mapeamento de rotas sugerido em cada título de seção acima).
- **Header**: desktop = pill nav central (Feed / Organizações / Comunidade / Chat) + botão "Cadastrar Pet" + sino de notificações (painel dropdown) + avatar com menu (Perfil, Meus Pets, Fazer Denúncia, Painel Admin se aplicável, Sair). Mobile = header compacto com back button contextual + bottom tab bar (Feed / ONGs / Cadastrar [destaque central elevado] / Chat com badge de não lidos / Perfil).
- **Toast**: notificação inferior centralizada, auto-some em 2.6s, usada para todas as confirmações de ação (interesse registrado, perfil salvo, convite enviado, etc.)
- **Modais**: notificações, confirmação de exclusão de conta, importação de planilha — todos com overlay escurecido e fecham ao clicar fora (exceto onde ação é destrutiva/precisa confirmação explícita).
- **Animações**: fade-up sutil (`translateY(14px)→0`, ~0.5s) em elementos de hero; swipe de cards com `transition` desabilitada durante o arrasto e reabilitada no soltar (`cubic-bezier(.2,.8,.2,1)`, 0.32s).

## State Management (sugestão para produção)
Estado que hoje vive só no protótipo e precisa de fonte real:
- **Auth/perfil**: Firebase Auth + doc `users/{uid}` com o perfil de adotante (housing, walks, budget, family, otherPets, lgpdConsentAt).
- **Pets**: coleção `pets` já existente — adicionar campo `ownerId` (uid ou orgId) e `ownerType` ('user' | 'org'), e os campos de temperamento/healthNotes/adoptionRequirements se ainda não existirem.
- **Organizações**: coleção `orgs` + subcoleção `orgs/{id}/members` com `{uid, role: 'owner'|'admin', permissions: {animals, finance, donations, feed, team}}`. Regras do Firestore devem checar essa subcoleção antes de liberar leitura/escrita das tabs administrativas.
- **Convites de equipe**: subcoleção `orgs/{id}/invites` com status pendente/aceito, resolvida via Cloud Function que cria o membro ao aceitar.
- **Doações**: subcoleção `orgs/{id}/campaigns`.
- **Financeiro**: subcoleção `orgs/{id}/ledger` com `{type: 'revenue'|'expense', category, value, date}` — os totais por período do protótipo devem virar agregações reais (Cloud Function ou query com filtro de data).
- **Importação de planilha**: Cloud Function que recebe o arquivo, parseia (SheetJS), valida linha a linha contra o schema de `pets`, detecta duplicados pelo campo-chave escolhido, e retorna o mesmo formato de preview do protótipo (`toInsert`, `duplicates`, `errors`) para o front decidir e confirmar.
- **Feed com raio de distância**: precisa de geocoding (Geocoding API ou base de lat/lng por cidade) + geohash no Firestore para queries de proximidade eficientes.

## Permissions Model (Organizações)
5 permissões atômicas por membro: `animals`, `finance`, `donations`, `feed`, `team`. O **owner** sempre tem todas e não pode ser editado/removido pela própria UI. Um admin só vê as tabs para as quais tem permissão `true`. Atribuir/revogar só pode ser feito por quem tem `team=true` (o próprio owner, ou um admin que o owner explicitamente marcou com `team=true`).

## Assets
Nenhum asset de imagem real usado — todos os "pets"/avatares no protótipo são placeholders (gradiente + ícone de pata). Trocar por fotos reais de upload do usuário/ONG. Ícones via Material Symbols Outlined — mapear para o set de ícones já usado no projeto (verificar `lucide-react`, presente nas dependências do shadcn/ui).
